# Databricks notebook source
#!pip3 install great_expectations
#!pip3 install ruamel_yaml
#!pip3 install Lektor 'MarkupSafe<2'

# COMMAND ----------

#imports
from ruamel import yaml
import datetime

from great_expectations.core.batch import RuntimeBatchRequest
from great_expectations.data_context import BaseDataContext
from great_expectations.data_context.types.base import (
    DataContextConfig,
    FilesystemStoreBackendDefaults,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Great expectations
# MAGIC ### we need create 4 objetcs: context, suite , dataframe, batch , with that objects we are going to build a batch/validator object that is a dataframe with the ability to receive expectations

# COMMAND ----------

# MAGIC %md
# MAGIC ### context

# COMMAND ----------

datasource_name = "MyDatasource"
conector = "DataConnector"
DataAsset= "ThisIsMyDataAsset"

# COMMAND ----------

#create a data context
root_directory = "/dbfs/great_expectations/"

data_context_config = DataContextConfig(
    store_backend_defaults=FilesystemStoreBackendDefaults(
        root_directory=root_directory
    ),
)
context = BaseDataContext(project_config=data_context_config)

# COMMAND ----------

#config my data source as a SparkDFExecutionEngine source

my_spark_datasource_config = {
    "name": datasource_name,
    "class_name": "Datasource",
    "execution_engine": {"class_name": "SparkDFExecutionEngine"},
    "data_connectors": {
        conector: {
            "module_name": "great_expectations.datasource.data_connector",
            "class_name": "RuntimeDataConnector",
            "batch_identifiers": [
                "some_key_maybe_pipeline_stage",
                "some_other_key_maybe_run_id",
            ],
        }
    },
}

# COMMAND ----------

#add the data source to my context
context.add_datasource(**my_spark_datasource_config)

# COMMAND ----------

# MAGIC %md 
# MAGIC ### data

# COMMAND ----------

#get_data
df = spark.read.format("delta")\
    .option("header", "true")\
    .option("inferSchema", "true")\
    .load("dbfs:/mnt/cg/publish/industrial/corporate/cost-system/cost-engine/std-coup/coup-accum")

# COMMAND ----------

# MAGIC %md 
# MAGIC ### batch 

# COMMAND ----------

#create the batch object

batch_request = RuntimeBatchRequest(
    datasource_name=datasource_name,
    data_connector_name=conector,
    data_asset_name=DataAsset,  # This can be anything that identifies this data_asset for you
    batch_identifiers={
        "some_key_maybe_pipeline_stage": "prod",
        "some_other_key_maybe_run_id": f"my_run_name_{datetime.date.today().strftime('%Y%m%d')}",
    },
    runtime_parameters={"batch_data": df},  # Your dataframe goes here
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### suite

# COMMAND ----------

expectation_suite_name = "suit_demo"
context.create_expectation_suite(
    expectation_suite_name=expectation_suite_name, overwrite_existing=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### validator

# COMMAND ----------

#validator 
validator = context.get_validator(
    batch_request=batch_request,
    expectation_suite_name=expectation_suite_name,
)

print(validator.head())

# COMMAND ----------

# MAGIC %md
# MAGIC ### and with that we can start to create expectations

# COMMAND ----------

validator.expect_column_values_to_not_be_null(column="id-mill")

# COMMAND ----------

validator.expect_column_values_to_not_be_null(column="group")

# COMMAND ----------

#save out expectations in a suite 
validator.save_expectation_suite(discard_failed_expectations=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ### validate data

# COMMAND ----------

my_checkpoint_name = "CheckPointName2"
checkpoint_config = {
    "name": my_checkpoint_name,
    "config_version": 1.0,
    "class_name": "SimpleCheckpoint",
    "run_name_template": "%Y%m%d-%H%M%S-my-run-name-template",
}

#my_checkpoint = context.test_yaml_config(yaml.dump(checkpoint_config))
#add the checkpoint to our  context
context.add_checkpoint(**checkpoint_config)

# COMMAND ----------

#run the checkpoint 
checkpoint_result = context.run_checkpoint(
    checkpoint_name=my_checkpoint_name,
    validations=[
        {
            "batch_request": batch_request,
            "expectation_suite_name": expectation_suite_name,
        }
    ],
)


# COMMAND ----------

# MAGIC %md 
# MAGIC ### get results and statistics 

# COMMAND ----------

checkpoint_result.get_statistics()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Docs

# COMMAND ----------

from IPython.core.display import display, HTML
display(HTML("<img src = '/dbfs/FileStore/f6e5111043887b63bb86cef041335238.html'>"))