# Databricks notebook source
!pip3 install great_expectations
!pip3 install pyteams
#great_expectation es una libreria externa, hay que instalarla en los cluster de databricks, en caso de un cluster job hay que instalarla cada vez que corra1

# COMMAND ----------

from datetime import datetime, timezone
import pandas as pd
import great_expectations as ge
import great_expectations.jupyter_ux
from great_expectations.exceptions import DataContextError
from great_expectations.data_context.types.base import DataContextConfig
from great_expectations.data_context.types.base import DatasourceConfig
from great_expectations.data_context.types.base import FilesystemStoreBackendDefaults
from great_expectations.data_context import BaseDataContext
from pathlib import Path
from os.path import abspath
import requests
import json
#import pymsteams

# COMMAND ----------

#great expectations necesita 3 objetos
#el primero es un data context que es un contexto que le damos a great expectations, lo mas importante es el motor en este caso se va a hacer con un motor de pandas que es mas limitado que uno spark en relacion a cantidad de datos
#el segundo es la suite que en resumen es la agrupacion de nuestras expectativas, es donde las vamos a ir almacenando por si las queremos reutilizar
#el tercero son los propios datos que en este caso tenemos que convertir el dataframe de spark a uno de pandas

# COMMAND ----------

# DBTITLE 1,Data Context
wproject_path = Path(abspath('')).parent.absolute().as_posix()
project_path

#si vemos en class_name se elige un motor de pandas (linea 12)
datasource = "my_pandas_datasource"
context = BaseDataContext(
                project_config=DataContextConfig(
                    config_version=2,
                    plugins_directory=f"{project_path}/plugins",
                    datasources={
                        datasource: DatasourceConfig(
                            class_name="PandasDatasource",
                            batch_kwargs_generators={}
                        )
                    },
                    validation_operators={
                        "action_list_operator": {
                            "class_name": "ActionListValidationOperator",
                            "action_list": [
                                {
                                    "name": "store_validation_result",
                                    "action": {"class_name": "StoreValidationResultAction"},
                                },
                                {
                                    "name": "update_data_docs",
                                    "action": {"class_name": "UpdateDataDocsAction"},
                                },
                            ],
                        }
                    },
                    store_backend_defaults=FilesystemStoreBackendDefaults(
                        root_directory=project_path
                    )
                )
            )

# COMMAND ----------

# DBTITLE 1,Suite
#creamos nuestra suite

expectation_suite_name = 'dataSQL'

try:
    suite = context.get_expectation_suite(expectation_suite_name)
except DataContextError:
    suite = context.create_expectation_suite(expectation_suite_name)
    
context.list_expectation_suite_names()

expectation_suite_name = "dataSQL"

# COMMAND ----------

# DBTITLE 1,getData
#obtenemos los datos y los pasamos a pandas
dfSpark = spark.read.format('delta').load('dbfs:/mnt/cg/publish/industrial/corporate/cost-system/cost-engine/energy-model-output')
df = dfSpark.toPandas()

# COMMAND ----------

display(df)

# COMMAND ----------

# DBTITLE 1,create the batch object( data, suite and context)
#creamos el objeto batch que es al cual le pasamos el contexto, los datos y la suite y ya le podemos preguntar sobre nuestras expectativas
batch_kwargs = {
    "datasource": "my_pandas_datasource",
    "dataset": df,
    "expectation_suite_names": expectation_suite_name
}

batch = context.get_batch(batch_kwargs, expectation_suite_name)
batch.head(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ### expectations

# COMMAND ----------

#por ejemplo podemos preguntar si no hay algun nulo en la columna LINE_ID y vemos que el success es true si la expectativa se cumple
#mas expectativas podemos encontrar aqui  https://greatexpectations.io/expectations/
batch.expect_column_values_to_not_be_null('LINE_ID')

# COMMAND ----------

#obtenemos las expectativa que fallan, podemos ir jugando con el json y obtener la info especifica que queremos33
sucess_expectations = batch.get_expectation_suite()
all_expectation = batch.get_expectation_suite(discard_failed_expectations=False)

for expectation in all_expectation["expectations"]:
    if  expectation not in sucess_expectations["expectations"]:
            print(expectation)
            

# COMMAND ----------

#a modo de agregacion podemos enviar como notificacion las expectativas falladas como mensaje de teams a un hook(configurar el link del hook al necesario)

sucess_expectations = batch.get_expectation_suite()
all_expectation = batch.get_expectation_suite(discard_failed_expectations=False)

for expectation in all_expectation["expectations"]:
    if  expectation not in sucess_expectations["expectations"]:
            print(expectation)
            
            # send failed expectations to teams
            myTeamsMessage = pymsteams.connectorcard("https://everisgroup.webhook.office.com/webhookb2/fc4b9c33-69d7-45c0-840a-c37efee45924@3048dc87-43f0-4100-9acb-ae1971c79395/IncomingWebhook/74c45985a38f4ebfafbbb32a1101cec7/c8e43f27-5282-4826-bd7e-98577dbed2d9")
            myTeamsMessage.text(f'hay una falla de calidad de datos en la columna {expectation["kwargs"]["column"]}')
            myTeamsMessage.send()