# Databricks notebook source
!pip3 install great-expectations --quiet

# COMMAND ----------

#imports
from ruamel import yaml
import datetime

from great_expectations.core.batch import RuntimeBatchRequest
from great_expectations.data_context import BaseDataContext
from great_expectations.data_context.types.base import (
    DataContextConfig,
    FilesystemStoreBackendDefaults,
)

# COMMAND ----------

dbutils.widgets.text("source", "")
dbutils.widgets.text("connector", "")
dbutils.widgets.text("asset", "")
dbutils.widgets.text("formatt", "")
dbutils.widgets.text("path", "")
dbutils.widgets.text("suite", "")

# COMMAND ----------

dataSourceName = dbutils.widgets.get("source")
connector = dbutils.widgets.get("connector")
dataAsset = dbutils.widgets.get("asset")
formato = dbutils.widgets.get("formatt")
path = dbutils.widgets.get("path")
suiteName= dbutils.widgets.get("suite")
root_directory = "/dbfs/great_expectations/"

# COMMAND ----------

class GreatExpectation:
    
    def __init__(self, dataSourceName, connector, dataAsset, formato, path , suiteName, root_directory):
        self.dataSourceName = dataSourceName
        self.connector = connector
        self.dataAsset = dataAsset
        self.root_directory = root_directory
        self.formato = formato
        self.path = path
        self.suiteName = suiteName
        
    def getData(self):
        df= spark.read.format(self.formato)\
            .option("header", "true")\
            .option("inferSchema", "true")\
            .load(self.path)
        return df
        
    def createContext(self) -> BaseDataContext:
        data_context_config = DataContextConfig(store_backend_defaults=FilesystemStoreBackendDefaults(root_directory=self.root_directory ),)
        context = BaseDataContext(project_config=data_context_config)
        
        context.create_expectation_suite(expectation_suite_name=self.suiteName, overwrite_existing=True) #Create a suite
        return context
    
    def createDataSource(self)-> dict :
        my_spark_datasource_config = {
        "name": self.dataSourceName,
        "class_name": "Datasource",
        "execution_engine": {"class_name": "SparkDFExecutionEngine"},
        "data_connectors": {
            self.connector: {
                "module_name": "great_expectations.datasource.data_connector",
                "class_name": "RuntimeDataConnector",
                "batch_identifiers": [
                    "some_key_maybe_pipeline_stage",
                    "some_other_key_maybe_run_id", ],} },}
        
        return my_spark_datasource_config
    
    def createBatch(self):      
        batch_request = RuntimeBatchRequest(
        datasource_name=self.dataSourceName,
        data_connector_name=self.connector,
        data_asset_name=self.dataAsset,  # This can be anything that identifies this data_asset for you
        batch_identifiers={
            "some_key_maybe_pipeline_stage": "prod",
            "some_other_key_maybe_run_id": f"my_run_name_{datetime.date.today().strftime('%Y%m%d')}",
        },
        runtime_parameters={"batch_data": df},)
        return batch_request
    
    
    def GetValidator(self):
        validator = context.get_validator(
            batch_request=batch_request,
            expectation_suite_name=self.suiteName,
        )

        return validator   
    
    

# COMMAND ----------

#create the GE Object
try : 
    GE = GreatExpectation(dataSourceName =dataSourceName,
                          connector= connector,
                          dataAsset = dataAsset,
                          suiteName = suiteName,
                          formato = formato,
                          path = path,
                          root_directory=root_directory                          
                          )

    df = GE.getData() #get the data

    context = GE.createContext() #get the data source
    my_spark_datasource_config = GE.createDataSource() #get data source
    context.add_datasource(**my_spark_datasource_config)

    batch_request = GE.createBatch() #get the batch
    validator = GE.GetValidator()
except Exception as e:
        print("***please remember that to use this notebook you need to pass: 1. dataSourceName as string -  2.connector as string - 3.dataAsset as string - 4.df as spark dataframe - 5.suiteName as string ***")
        print("**1 ,2 , 3 and 5 can be anything that identifies that for you, always without "" or ''")
        
        print("----------------------------------------------------------------------------------------")
        print("EXAMPLE: %run ./GreatExpectationObject $source=mySource $connector = MyConnector $asset=MyAsset $formatt=delta $path=dbfs:/etc/etc/ $suite=MySuite")
        print("----------------------------------------------------------------------------------------")
        
        print("----------------------------------------------------------------------------------------")
        print("----------------------------------------------------------------------------------------")
        print("if you added the parameters correctly then check the error:")
        print(f"an error occurred due to {e}")
        raise Exception(f'{e}') 

# COMMAND ----------

print("Now you can validate your data with validator object!! for example, you can run validator.expect_column_values_to_not_be_null('<column name')")