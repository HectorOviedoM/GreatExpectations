# Databricks notebook source
from ruamel import yaml

import great_expectations as ge
from great_expectations.core.batch import BatchRequest, RuntimeBatchRequest
from great_expectations.data_context import BaseDataContext
from great_expectations.data_context.types.base import (
    DataContextConfig,
    InMemoryStoreBackendDefaults)

# COMMAND ----------

# DBTITLE 1,Data Context
datasource_config = {
    "name": "my_spark_dataframe",
    "class_name": "Datasource",
    "execution_engine": {"class_name": "SparkDFExecutionEngine"},
    "data_connectors": {
        "default_runtime_data_connector_name": {
            "class_name": "RuntimeDataConnector",
            "batch_identifiers": ["batch_id"], }},}

context.add_datasource(**datasource_config)

# COMMAND ----------

#get_data
df = spark.read.format("delta")\
    .option("header", "true")\
    .option("inferSchema", "true")\
    .load("dbfs:/mnt/cg/publish/industrial/corporate/cost-system/cost-engine/std-coup/coup-accum")

# COMMAND ----------

#create the batch_request

batch_request = RuntimeBatchRequest(
    datasource_name="my_spark_dataframe",
    data_connector_name="default_runtime_data_connector_name",
    data_asset_name="asset",
    batch_identifiers={"batch_id": "default_identifier"},
    runtime_parameters={"batch_data": df})

# COMMAND ----------

#create the suite
context.create_expectation_suite(expectation_suite_name="test_suite", overwrite_existing=True)

#create the validator
validator = context.get_validator(batch_request=batch_request, expectation_suite_name="test_suite")

# COMMAND ----------

#expectations
validator.expect_column_values_to_not_be_null(column="id-mill")

# COMMAND ----------

validator.expect_column_values_to_not_be_null(column="group")

# COMMAND ----------

# DBTITLE 1,Validate Data
sucess_expectations = validator.get_expectation_suite()
all_expectation = validator.get_expectation_suite(discard_failed_expectations=False)

expect= 0
failed = 0
for expectation in all_expectation["expectations"]:
    expect +=1
    if  expectation not in sucess_expectations["expectations"]:
            print(expectation)
            failed +=1
print("------------------------------------------------")
print(f"We have {expect} expectations, {failed} of them failed")
print(f'{(failed *100)/expect} percent failed')